$(document).ready(function() {
						   
	$("#countdown").countdown({
				date: "25 january 2016 11:00:00",
				format: "on"
			},
			
			function() {
				// callback function
			});

});